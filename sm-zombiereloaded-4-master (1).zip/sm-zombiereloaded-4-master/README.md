# sm-zombiereloaded-4
Zombie:Reloaded for SourceMod This version will soon no longer work on CS:GO

Q: Why this zombiereloaded existed?

A: I just wanna work on my version of zombie:reloaded and have a new syntax. Srcdslab version did a pretty good job bringing zombie:reloaded with new syntax. Thanks to them it's now possible to zr plugin finally work with sourcemod 1.12 legit witout have to use old complier. 

### List that I have been work so far.
- ZVolume (You can change Zombie volume, Ambient Volume "separately".) 
- Knockback API
- ZMarket API
- Actual weapon knockback for csgo.
- Fix last human not turn into zombie.
- Mother Zombie cycle. (Mapeadores)
- Round End Screen (Franc1sco)
- Weapon Purchase Command (srcdslab)

### Some Code reference from these. 
- https://github.com/srcdslab/sm-plugin-zombiereloaded
- https://github.com/Franc1sco/sm-zombiereloaded-3-Franug-Edition
- https://github.com/Mapeadores/ZombieReloaded

